﻿namespace XZAM_App
{
    partial class frmAdminChangePassword
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnAccept = new System.Windows.Forms.Button();
            this.lbEditUsername = new System.Windows.Forms.Label();
            this.lbEditPassword = new System.Windows.Forms.Label();
            this.txtEditUsername = new System.Windows.Forms.TextBox();
            this.txtEditPassword = new System.Windows.Forms.TextBox();
            this.btnCancel = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnAccept
            // 
            this.btnAccept.DialogResult = System.Windows.Forms.DialogResult.OK;
            this.btnAccept.Location = new System.Drawing.Point(76, 181);
            this.btnAccept.Name = "btnAccept";
            this.btnAccept.Size = new System.Drawing.Size(79, 23);
            this.btnAccept.TabIndex = 0;
            this.btnAccept.Text = "Accept";
            this.btnAccept.UseVisualStyleBackColor = true;
            this.btnAccept.Click += new System.EventHandler(this.btnAccept_Click);
            // 
            // lbEditUsername
            // 
            this.lbEditUsername.AutoSize = true;
            this.lbEditUsername.Location = new System.Drawing.Point(38, 71);
            this.lbEditUsername.Name = "lbEditUsername";
            this.lbEditUsername.Size = new System.Drawing.Size(55, 13);
            this.lbEditUsername.TabIndex = 1;
            this.lbEditUsername.Text = "Username";
            // 
            // lbEditPassword
            // 
            this.lbEditPassword.AutoSize = true;
            this.lbEditPassword.Location = new System.Drawing.Point(38, 116);
            this.lbEditPassword.Name = "lbEditPassword";
            this.lbEditPassword.Size = new System.Drawing.Size(53, 13);
            this.lbEditPassword.TabIndex = 2;
            this.lbEditPassword.Text = "Password";
            // 
            // txtEditUsername
            // 
            this.txtEditUsername.Enabled = false;
            this.txtEditUsername.Location = new System.Drawing.Point(125, 64);
            this.txtEditUsername.Name = "txtEditUsername";
            this.txtEditUsername.Size = new System.Drawing.Size(129, 20);
            this.txtEditUsername.TabIndex = 3;
            // 
            // txtEditPassword
            // 
            this.txtEditPassword.Location = new System.Drawing.Point(125, 109);
            this.txtEditPassword.Name = "txtEditPassword";
            this.txtEditPassword.Size = new System.Drawing.Size(129, 20);
            this.txtEditPassword.TabIndex = 4;
            this.txtEditPassword.Text = " ";
            // 
            // btnCancel
            // 
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btnCancel.Location = new System.Drawing.Point(175, 181);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(79, 23);
            this.btnCancel.TabIndex = 5;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // frmAdminChangePassword
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.txtEditPassword);
            this.Controls.Add(this.txtEditUsername);
            this.Controls.Add(this.lbEditPassword);
            this.Controls.Add(this.lbEditUsername);
            this.Controls.Add(this.btnAccept);
            this.Name = "frmAdminChangePassword";
            this.Text = "frmAdminChangePassword";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnAccept;
        private System.Windows.Forms.Label lbEditUsername;
        private System.Windows.Forms.Label lbEditPassword;
        private System.Windows.Forms.TextBox txtEditUsername;
        private System.Windows.Forms.TextBox txtEditPassword;
        private System.Windows.Forms.Button btnCancel;
    }
}