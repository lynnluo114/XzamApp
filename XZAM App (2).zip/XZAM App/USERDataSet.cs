﻿namespace XZAM_App
{


    partial class USERDataSet
    {
    }
}

namespace XZAM_App.USERDataSetTableAdapters {
    
    
    public partial class USER_TABLETableAdapter {
    }
}
