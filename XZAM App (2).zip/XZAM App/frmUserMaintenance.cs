﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace XZAM_App
{

    public partial class frmUserMaintenance : Form
    {
        SqlDataReader reader;
        public frmUserMaintenance()
        {
            InitializeComponent();
        }
        //Connect String Datasource
        string cs = @"Data Source=VAIO\SQLEXPRESS;Initial Catalog=USER;Integrated Security=True";

        private void frmUserMaintenance_Load(object sender, EventArgs e)
        {
            this.userTableAdapter.Fill(this.userDataSet.USER_TABLE);
        }

        private void ClickEdit(object sender, DataGridViewCellEventArgs e)
        {

            if (uSER_TABLEDataGridView.CurrentCell.ColumnIndex == 4)
            {
                var row = uSER_TABLEDataGridView.CurrentRow;
                frmAdminChangePassword form = new frmAdminChangePassword();

                var txt1 = form.Controls["txtEditUsername"];
                var txt2 = form.Controls["txtEditPassword"];
                txt1.Text = row.Cells[1].Value.ToString();
                txt2.Text = row.Cells[2].Value.ToString();
                int id = Int32.Parse(row.Cells[0].Value.ToString());
                string name = row.Cells[3].Value.ToString();

                if (form.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    try
                    {
                        if (txt2.Text != null)
                        {
                            row.Cells[2].Value = txt2.Text;
                            SqlConnection connectSql = new SqlConnection(cs);
                            
                            SqlCommand cmd = new SqlCommand("update USER_TABLE SET Password=@Pass WHERE Id = @uid", connectSql);
                            cmd.Parameters.AddWithValue("@uid", id);
                            cmd.Parameters.AddWithValue("@Pass", txt2.Text);
                            connectSql.Open();
                            cmd.ExecuteNonQuery();
                            connectSql.Close();
                        }

                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Password is not changed" +ex);
                    }

                }

            }
            //delete user

            else if (uSER_TABLEDataGridView.CurrentCell.ColumnIndex == 5)
            {
                var row = uSER_TABLEDataGridView.CurrentRow;
                int id = Int32.Parse(row.Cells[0].Value.ToString());

                if (uSER_TABLEDataGridView.CurrentCell.ColumnIndex > 1)
                {
                    uSER_TABLEDataGridView.Rows.Remove(row);
                    try
                    {
                        SqlConnection connectSql = new SqlConnection(cs);
                        connectSql.Open();
                        SqlCommand cmd = new SqlCommand("DELETE USER_TABLE WHERE Id = @Id", connectSql);
                        cmd.Parameters.AddWithValue("@Id", id);
                        cmd.ExecuteNonQuery();
                        connectSql.Close();
                    }
                    catch (Exception exp)
                    {
                        MessageBox.Show("SQL error" + exp);
                    }

                }
            }


        }


        private void btnAddNewStudent_Click(object sender, EventArgs e)
        {
            int id;
            frmAddNewStudent form = new frmAddNewStudent();
            var textId = form.Controls["txtAddId"];
            var textUsername = form.Controls["txtAddUsername"];
            var textPassword = form.Controls["txtAddPassword"];
            var textName = form.Controls["txtAddName"];

            if (form.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                try
                {
                    id = Int32.Parse(textId.Text);
                    userTableAdapter.Insert(id, textUsername.Text, textPassword.Text, textName.Text);
                    this.userTableAdapter.Fill(this.userDataSet.USER_TABLE);
                }
                catch (Exception ex)
                {

                }
            }
        }
        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {

                MessageBox.Show("Update successful");
            }
            catch (Exception exp)
            {
                MessageBox.Show("Update fail");
            }

        }
















        private void ClickRemove(object sender, DataGridViewCellEventArgs e)
        {

        }


        private void userDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void uSER_TABLEDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }


    }
}
