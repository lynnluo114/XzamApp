﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace XZAM_App
{
    public partial class frmLogin : Form
    {
        SqlDataReader reader;
        public frmLogin()
        {
            InitializeComponent();
        }
        //Connect String Datasource
        string cs = @"Data Source=VAIO\SQLEXPRESS;Initial Catalog=USER;Integrated Security=True";

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            if(txtUserNLogin.Text=="" )
            {
                MessageBox.Show("Please enter your Username");
                return;
            }
            else if (txtPasswordLogin.Text == "")
            {
                MessageBox.Show("Please enter your Password");
            }
            try {
                //Create SqlConnection
                SqlConnection connectSql = new SqlConnection(cs);
                SqlCommand cmd = new SqlCommand("Select * from USER_TABLE where Username=@username and Password=@password", connectSql);
                cmd.Parameters.AddWithValue("username", txtUserNLogin.Text);
                cmd.Parameters.AddWithValue("password", txtPasswordLogin.Text);
                connectSql.Open();
                reader = cmd.ExecuteReader();


                if (reader.Read())
                {
                    if (txtUserNLogin.Text == "Admin")
                    {
                        MessageBox.Show("You are Admin");
                        frmMDI form = new frmMDI();
                        form.Show();
                    }
                    MessageBox.Show("You are logged In");
                    this.Close();
                }
                else
                {
                    MessageBox.Show("Please correct your username and password");
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        private void btnLogOut_Click(object sender, EventArgs e)
        {
            this.Hide();
            
        }


        private void label1_Click(object sender, EventArgs e)
        {

        }
        private void txtUsername_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void txtPassword_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        private void frmLogin_Load(object sender, EventArgs e)
        {
           

        }
    }
}
