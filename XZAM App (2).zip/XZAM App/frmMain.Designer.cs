﻿namespace XZAM_App
{
    partial class frmMDI
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMDI));
            this.MainMenuStrip = new System.Windows.Forms.MenuStrip();
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.mnuUserManagerment = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuManagerExam = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuQuestionBank = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuChangePassword = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuViewSchedule = new System.Windows.Forms.ToolStripMenuItem();
            this.windowToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuArrangeVertically = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuArrangeHorizontally = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuCascadeAllWindows = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuCloseAllChildWindows = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuExitApplicationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripTimeSchedule = new System.Windows.Forms.ToolStrip();
            this.toolStripButtonUserManagement = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonExamMangement = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonQuestionBank = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonTimeSchedule = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonChangePassword = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButtonLogout = new System.Windows.Forms.ToolStripButton();
            this.MainMenuStrip.SuspendLayout();
            this.toolStripTimeSchedule.SuspendLayout();
            this.SuspendLayout();
            // 
            // MainMenuStrip
            // 
            this.MainMenuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.windowToolStripMenuItem,
            this.mnuExitApplicationToolStripMenuItem});
            this.MainMenuStrip.Location = new System.Drawing.Point(0, 0);
            this.MainMenuStrip.Name = "MainMenuStrip";
            this.MainMenuStrip.Size = new System.Drawing.Size(1090, 24);
            this.MainMenuStrip.TabIndex = 1;
            this.MainMenuStrip.Text = "MainMenuStrip";
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripSeparator1,
            this.mnuUserManagerment,
            this.mnuManagerExam,
            this.mnuQuestionBank,
            this.mnuChangePassword,
            this.mnuViewSchedule});
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(50, 20);
            this.toolStripMenuItem1.Text = "Menu";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(172, 6);
            // 
            // mnuUserManagerment
            // 
            this.mnuUserManagerment.Name = "mnuUserManagerment";
            this.mnuUserManagerment.Size = new System.Drawing.Size(175, 22);
            this.mnuUserManagerment.Text = "User Managerment";
            // 
            // mnuManagerExam
            // 
            this.mnuManagerExam.Name = "mnuManagerExam";
            this.mnuManagerExam.Size = new System.Drawing.Size(175, 22);
            this.mnuManagerExam.Text = "Manager Exam";
            // 
            // mnuQuestionBank
            // 
            this.mnuQuestionBank.Name = "mnuQuestionBank";
            this.mnuQuestionBank.Size = new System.Drawing.Size(175, 22);
            this.mnuQuestionBank.Text = "Question Bank";
            // 
            // mnuChangePassword
            // 
            this.mnuChangePassword.Name = "mnuChangePassword";
            this.mnuChangePassword.Size = new System.Drawing.Size(175, 22);
            this.mnuChangePassword.Text = "Change Password";
            this.mnuChangePassword.Click += new System.EventHandler(this.mnuChangePassword_Click);
            // 
            // mnuViewSchedule
            // 
            this.mnuViewSchedule.Name = "mnuViewSchedule";
            this.mnuViewSchedule.Size = new System.Drawing.Size(175, 22);
            this.mnuViewSchedule.Text = "View Schedule";
            // 
            // windowToolStripMenuItem
            // 
            this.windowToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuArrangeVertically,
            this.mnuArrangeHorizontally,
            this.mnuCascadeAllWindows,
            this.mnuCloseAllChildWindows});
            this.windowToolStripMenuItem.Name = "windowToolStripMenuItem";
            this.windowToolStripMenuItem.Size = new System.Drawing.Size(63, 20);
            this.windowToolStripMenuItem.Text = "Window";
            // 
            // mnuArrangeVertically
            // 
            this.mnuArrangeVertically.Name = "mnuArrangeVertically";
            this.mnuArrangeVertically.Size = new System.Drawing.Size(203, 22);
            this.mnuArrangeVertically.Text = "Arrange Vertically";
            this.mnuArrangeVertically.Click += new System.EventHandler(this.mnuArrangeVertically_Click);
            // 
            // mnuArrangeHorizontally
            // 
            this.mnuArrangeHorizontally.Name = "mnuArrangeHorizontally";
            this.mnuArrangeHorizontally.Size = new System.Drawing.Size(203, 22);
            this.mnuArrangeHorizontally.Text = "Arrange Horizontally";
            this.mnuArrangeHorizontally.Click += new System.EventHandler(this.mnuArrangeHorizontally_Click);
            // 
            // mnuCascadeAllWindows
            // 
            this.mnuCascadeAllWindows.Name = "mnuCascadeAllWindows";
            this.mnuCascadeAllWindows.Size = new System.Drawing.Size(203, 22);
            this.mnuCascadeAllWindows.Text = "Cascade All Windows";
            this.mnuCascadeAllWindows.Click += new System.EventHandler(this.mnuCascadeAllWindows_Click);
            // 
            // mnuCloseAllChildWindows
            // 
            this.mnuCloseAllChildWindows.Name = "mnuCloseAllChildWindows";
            this.mnuCloseAllChildWindows.Size = new System.Drawing.Size(203, 22);
            this.mnuCloseAllChildWindows.Text = "Close All Child Windows";
            this.mnuCloseAllChildWindows.Click += new System.EventHandler(this.mnuCloseAllChildWindows_Click);
            // 
            // mnuExitApplicationToolStripMenuItem
            // 
            this.mnuExitApplicationToolStripMenuItem.Name = "mnuExitApplicationToolStripMenuItem";
            this.mnuExitApplicationToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.F4)));
            this.mnuExitApplicationToolStripMenuItem.Size = new System.Drawing.Size(60, 20);
            this.mnuExitApplicationToolStripMenuItem.Text = "Log out";
            this.mnuExitApplicationToolStripMenuItem.Click += new System.EventHandler(this.mnuExitApplicationToolStripMenuItem_Click);
            // 
            // toolStripTimeSchedule
            // 
            this.toolStripTimeSchedule.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.toolStripTimeSchedule.Dock = System.Windows.Forms.DockStyle.None;
            this.toolStripTimeSchedule.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripTimeSchedule.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButtonUserManagement,
            this.toolStripButtonExamMangement,
            this.toolStripButtonQuestionBank,
            this.toolStripButtonTimeSchedule,
            this.toolStripButtonChangePassword,
            this.toolStripSeparator2,
            this.toolStripButtonLogout});
            this.toolStripTimeSchedule.Location = new System.Drawing.Point(104, 24);
            this.toolStripTimeSchedule.Name = "toolStripTimeSchedule";
            this.toolStripTimeSchedule.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
            this.toolStripTimeSchedule.Size = new System.Drawing.Size(974, 84);
            this.toolStripTimeSchedule.TabIndex = 3;
            this.toolStripTimeSchedule.Text = "Time Schedule";
            // 
            // toolStripButtonUserManagement
            // 
            this.toolStripButtonUserManagement.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripButtonUserManagement.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonUserManagement.Image")));
            this.toolStripButtonUserManagement.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButtonUserManagement.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonUserManagement.Name = "toolStripButtonUserManagement";
            this.toolStripButtonUserManagement.Size = new System.Drawing.Size(189, 81);
            this.toolStripButtonUserManagement.Text = "User Managerment";
            this.toolStripButtonUserManagement.Click += new System.EventHandler(this.toolStripButtonUserManagement_Click);
            // 
            // toolStripButtonExamMangement
            // 
            this.toolStripButtonExamMangement.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonExamMangement.Image")));
            this.toolStripButtonExamMangement.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButtonExamMangement.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonExamMangement.Name = "toolStripButtonExamMangement";
            this.toolStripButtonExamMangement.Size = new System.Drawing.Size(204, 81);
            this.toolStripButtonExamMangement.Text = "Exam Management";
            this.toolStripButtonExamMangement.Click += new System.EventHandler(this.toolStripButtonExamMangement_Click);
            // 
            // toolStripButtonQuestionBank
            // 
            this.toolStripButtonQuestionBank.BackColor = System.Drawing.SystemColors.Control;
            this.toolStripButtonQuestionBank.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.toolStripButtonQuestionBank.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripButtonQuestionBank.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonQuestionBank.Image")));
            this.toolStripButtonQuestionBank.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButtonQuestionBank.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonQuestionBank.Name = "toolStripButtonQuestionBank";
            this.toolStripButtonQuestionBank.Size = new System.Drawing.Size(149, 81);
            this.toolStripButtonQuestionBank.Text = "Question Bank";
            this.toolStripButtonQuestionBank.Click += new System.EventHandler(this.toolStripButtonQuestionBank_Click);
            // 
            // toolStripButtonTimeSchedule
            // 
            this.toolStripButtonTimeSchedule.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.toolStripButtonTimeSchedule.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonTimeSchedule.Image")));
            this.toolStripButtonTimeSchedule.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButtonTimeSchedule.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonTimeSchedule.Name = "toolStripButtonTimeSchedule";
            this.toolStripButtonTimeSchedule.Size = new System.Drawing.Size(164, 81);
            this.toolStripButtonTimeSchedule.Text = "Time Schedule ";
            this.toolStripButtonTimeSchedule.Click += new System.EventHandler(this.toolStripButtonTimeSchedule_Click);
            // 
            // toolStripButtonChangePassword
            // 
            this.toolStripButtonChangePassword.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButtonChangePassword.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonChangePassword.Image")));
            this.toolStripButtonChangePassword.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButtonChangePassword.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonChangePassword.Name = "toolStripButtonChangePassword";
            this.toolStripButtonChangePassword.Size = new System.Drawing.Size(84, 81);
            this.toolStripButtonChangePassword.Click += new System.EventHandler(this.toolStripButtonChangePassword_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 84);
            // 
            // toolStripButtonLogout
            // 
            this.toolStripButtonLogout.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButtonLogout.Image")));
            this.toolStripButtonLogout.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.toolStripButtonLogout.ImageScaling = System.Windows.Forms.ToolStripItemImageScaling.None;
            this.toolStripButtonLogout.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButtonLogout.Name = "toolStripButtonLogout";
            this.toolStripButtonLogout.Size = new System.Drawing.Size(135, 81);
            this.toolStripButtonLogout.Text = "Log out";
            this.toolStripButtonLogout.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.toolStripButtonLogout.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.toolStripButtonLogout.Click += new System.EventHandler(this.toolStripButtonLogout_Click);
            // 
            // frmMDI
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.AutoValidate = System.Windows.Forms.AutoValidate.Disable;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1090, 391);
            this.Controls.Add(this.toolStripTimeSchedule);
            this.Controls.Add(this.MainMenuStrip);
            this.DoubleBuffered = true;
            this.ForeColor = System.Drawing.Color.Black;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.Name = "frmMDI";
            this.Text = "XZAM MDI Application";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmMDI_Load);
            this.MainMenuStrip.ResumeLayout(false);
            this.MainMenuStrip.PerformLayout();
            this.toolStripTimeSchedule.ResumeLayout(false);
            this.toolStripTimeSchedule.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip MainMenuStrip;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem mnuUserManagerment;
        private System.Windows.Forms.ToolStripMenuItem mnuManagerExam;
        private System.Windows.Forms.ToolStripMenuItem mnuQuestionBank;
        private System.Windows.Forms.ToolStripMenuItem mnuChangePassword;
        private System.Windows.Forms.ToolStripMenuItem mnuViewSchedule;
        private System.Windows.Forms.ToolStripMenuItem windowToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mnuArrangeVertically;
        private System.Windows.Forms.ToolStripMenuItem mnuArrangeHorizontally;
        private System.Windows.Forms.ToolStripMenuItem mnuCascadeAllWindows;
        private System.Windows.Forms.ToolStripMenuItem mnuCloseAllChildWindows;
        private System.Windows.Forms.ToolStripMenuItem mnuExitApplicationToolStripMenuItem;
        private System.Windows.Forms.ToolStrip toolStripTimeSchedule;
        private System.Windows.Forms.ToolStripButton toolStripButtonQuestionBank;
        private System.Windows.Forms.ToolStripButton toolStripButtonUserManagement;
        private System.Windows.Forms.ToolStripButton toolStripButtonTimeSchedule;
        private System.Windows.Forms.ToolStripButton toolStripButtonExamMangement;
        private System.Windows.Forms.ToolStripButton toolStripButtonChangePassword;
        private System.Windows.Forms.ToolStripButton toolStripButtonLogout;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
    }
}

