﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace XZAM_App
{
    public partial class frmMDI : Form
    {
        string cs = @"Data Source=VAIO\SQLEXPRESS;Initial Catalog=USER;Integrated Security=True";

        public frmMDI()
        {
            InitializeComponent();

        }

        private void mnuArrangeVertically_Click(object sender, EventArgs e)
        {
            this.LayoutMdi(MdiLayout.TileHorizontal);
        }

        private void mnuArrangeHorizontally_Click(object sender, EventArgs e)
        {
            this.LayoutMdi(MdiLayout.TileHorizontal);
        }

        private void mnuCascadeAllWindows_Click(object sender, EventArgs e)
        {
            this.LayoutMdi(MdiLayout.Cascade);
        }

        private void mnuCloseAllChildWindows_Click(object sender, EventArgs e)
        {
            foreach (Form x in this.MdiChildren)
            {
                x.Close();
            }
        }

        private void mnuExitApplicationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult button =
            MessageBox.Show("Do you want to Logout?", "Next Action...", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1);
            if (button == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void frmMDI_Load(object sender, EventArgs e)
        {

            frmLogin frm = new frmLogin();
            frm.MdiParent = this;
            frm.Show();

        }

        private void mnuChangePassword_Click(object sender, EventArgs e)
        {

        }

        private void toolStripButtonLogout_Click(object sender, EventArgs e)
        {
            DialogResult button =
            MessageBox.Show("Do you want to Logout?", "Next Action...", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1);
            if (button == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void toolStripButtonUserManagement_Click(object sender, EventArgs e)
        {

            frmUserMaintenance frm = new frmUserMaintenance();
            frm.MdiParent = this;
            frm.Show();
        }

        private void toolStripButtonChangePassword_Click(object sender, EventArgs e)
        {
            foreach (Form x in this.MdiChildren)
            {
                x.Close();
            }

            //frmAdminChangePassword form = new frmAdminChangePassword();
            //var txt1 = form.Controls["txtEditPassword"];
            //var txt2 = form.Controls["txtEditUsername"];
            //SqlConnection connectSql = new SqlConnection(cs);
            //SqlCommand cmd = new SqlCommand("Select * from USER_TABLE where Username=@username and Password=@password", connectSql);
            //cmd.Parameters.AddWithValue("username", txt2.Text);
            //cmd.Parameters.AddWithValue("password", txt1.Text);
            //connectSql.Open();

            //if (form.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            //{
            //    try
            //    {
            //        if (txt1.Text != null)
            //        {
            //            cmd = new SqlCommand("update USER_TABLE SET Password=@Pass WHERE Id = @uid", connectSql);
            //            cmd.Parameters.AddWithValue("@uid", txt2.Text);
            //            cmd.Parameters.AddWithValue("@Pass", txt1.Text);
            //            connectSql.Open();
            //            cmd.ExecuteNonQuery();
            //            connectSql.Close();
            //        }
            //    }
            //    catch (Exception ex)
            //    {
            //        MessageBox.Show("SQL error" + ex);
            //    }
            //}
        }
        frmQuestionBankSetup frm2 = new frmQuestionBankSetup();
        private void toolStripButtonExamMangement_Click(object sender, EventArgs e)
        {
            
            
            if (frm2.IsDisposed) { frm2 = new frmQuestionBankSetup(); }
            else {
                foreach (Form x in this.MdiChildren)
            {
                x.Close();
            } }
            frm2.Show();
        }
        frmQuestionSetup frm3 = new frmQuestionSetup();
        private void toolStripButtonQuestionBank_Click(object sender, EventArgs e)
        {
            foreach (Form x in this.MdiChildren)
            {
                x.Close();
            }
            if (frm2.IsDisposed) { frm3 = new frmQuestionSetup(); }
            frm3.Show();
        }
        frmSchedulerCreation frm4 = new frmSchedulerCreation();
        private void toolStripButtonTimeSchedule_Click(object sender, EventArgs e)
        {
            foreach (Form x in this.MdiChildren)
            {
                x.Close();
            }
            if (frm4.IsDisposed) { frm4 = new frmSchedulerCreation(); }
            frm4.Show();
        }
    }
}
