﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Xzam
{
    public partial class frmMain : Form
    {
        private string username;
        private string password;

        public frmMain()
        {
            InitializeComponent();

        }
        public frmMain(string username, string password) : this()
        {
            this.username = username;
            this.password = password;
        }

        frmUserMaintenance frm1 = new frmUserMaintenance();
        private void toolStripButtonUserManagement_Click(object sender, EventArgs e)
        {
            if (frm1.IsDisposed)
            {
                frm1 = new frmUserMaintenance();
            }
            frm1.ShowDialog();
            frm2.Close();
            frm3.Close();
            frm4.Close();
            frm5.Close();
        }
        frmQuestionBankSetup frm2 = new frmQuestionBankSetup();
        private void toolStripButtonExamManagement_Click(object sender, EventArgs e)
        {
            if (frm2.IsDisposed) { frm2 = new frmQuestionBankSetup(); }
            frm2.ShowDialog();
            frm1.Close();
            frm3.Close();
            frm4.Close();
            frm5.Close();
        }
        frmQuestionSetup frm3 = new frmQuestionSetup();
        private void toolStripButtonQuestionBank_Click(object sender, EventArgs e)
        {
            if (frm3.IsDisposed) { frm3 = new frmQuestionSetup(); }
            frm3.ShowDialog();
            frm1.Close();
            frm2.Close();
            frm4.Close();
            frm5.Close();
        }
        frmSchedulerCreation frm4 = new frmSchedulerCreation();
        private void toolStripButtonTimeSchedule_Click(object sender, EventArgs e)
        {
            if (frm4.IsDisposed) { frm4 = new frmSchedulerCreation(); }
            frm4.ShowDialog();
            frm2.Close();
            frm3.Close();
            frm1.Close();
            frm5.Close();
        }

        private void toolStripButtonLogout_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            if (username == "Admin")
            {
                toolStripButtonChangePassword.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.None;
                toolStripButtonChangePassword.Enabled = false;
            }
            else
            {
                toolStripButtonExamManagement.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.None;
                toolStripButtonExamManagement.Enabled = false;
                toolStripButtonQuestionBank.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.None;
                toolStripButtonQuestionBank.Enabled = false;
                toolStripButtonUserManagement.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.None;
                toolStripButtonUserManagement.Enabled = false;
            }
        }
        frmChangePassword frm5 = new frmChangePassword();
        private void toolStripButtonChangePassword_Click(object sender, EventArgs e)
        {
            frm5.passValuePassword = password;
            frm5.passValueUsername = username;
    
            if (frm5.IsDisposed)
            {
                frm5 = new frmChangePassword();
                var text = frm5.Controls["txtCurrentPassword"];
                text.Text = password;
            }
            frm5.ShowDialog();

            frm4.Close();
            frm2.Close();
            frm3.Close();
            frm1.Close();
        }


        private void userManagementToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (frm1.IsDisposed)
            {
                frm1 = new frmUserMaintenance();
            }
            frm1.Show();
            frm2.Close();
            frm3.Close();
            frm4.Close();
            frm5.Close();
        }

        private void managerExamToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (frm2.IsDisposed) { frm2 = new frmQuestionBankSetup(); }
            frm2.Show();
            frm1.Close();
            frm3.Close();
            frm4.Close();
            frm5.Close();
        }

        private void questionBankToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (frm3.IsDisposed) { frm3 = new frmQuestionSetup(); }
            frm3.Show();
            frm1.Close();
            frm2.Close();
            frm4.Close();
            frm5.Close();
        }

        private void changePasswordToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frm5.passValuePassword = password;
            frm5.passValueUsername = username;
            //if (username != "Admin" )
            //{
            //    MessageBox.Show("user");
            if (frm5.IsDisposed)
            {
                frm5 = new frmChangePassword();
                var text = frm5.Controls["txtCurrentPassword"];
                text.Text = password;
            }
            frm5.Show();
            //}
            frm4.Close();
            frm2.Close();
            frm3.Close();
            frm1.Close();
        }

        private void viewScheduleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (frm4.IsDisposed) { frm4 = new frmSchedulerCreation(); }
            frm4.Show();
            frm2.Close();
            frm3.Close();
            frm1.Close();
            frm5.Close();
        }


        private void menuToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
