﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Xzam
{
    public partial class frmChangePassword : Form
    {
        public frmChangePassword()
        {
            InitializeComponent();
        }
        private string password;
        public string passValue
        {
            set { password = value; }
            get { return password; }
        }
        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnUserChangePassword_Click(object sender, EventArgs e)
        {
            DialogResult = System.Windows.Forms.DialogResult.OK;

            //check password validate value
            MessageBox.Show("Change Password Successful!");
            this.Close();
        }

        private void btnUserCancelChangePass_Click(object sender, EventArgs e)
        {
            DialogResult = System.Windows.Forms.DialogResult.Cancel;
        }

        private void txtConfirmPassword_TextChanged(object sender, EventArgs e)
        {

        }

        private void frmChangePassword_Load(object sender, EventArgs e)
        {
            txtCurrentPassword.Text = password;
        }
    }
}
