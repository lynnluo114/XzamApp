﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Xzam
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }
        
        private void toolStripButtonUserManagement_Click(object sender, EventArgs e)
        {
            frmUserMaintenance frm = new frmUserMaintenance();
            if (frm.IsDisposed) { frm = new frmUserMaintenance(); }
            frm.Show();

        }

        private void toolStripButtonExamManagement_Click(object sender, EventArgs e)
        {
            frmQuestionBankSetup frm = new frmQuestionBankSetup();
            if (frm.IsDisposed) { frm = new frmQuestionBankSetup(); }
            frm.Show();
        }

        private void toolStripButtonQuestionBank_Click(object sender, EventArgs e)
        {
            frmQuestionSetup frm = new frmQuestionSetup();
            if (frm.IsDisposed) { frm = new frmQuestionSetup(); }
            frm.Show();
        }

        private void toolStripButtonTimeSchedule_Click(object sender, EventArgs e)
        {
            frmSchedulerCreation frm = new frmSchedulerCreation();
            if (frm.IsDisposed) { frm = new frmSchedulerCreation(); }
            frm.Show();
        }

        private void toolStripButtonLogout_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
